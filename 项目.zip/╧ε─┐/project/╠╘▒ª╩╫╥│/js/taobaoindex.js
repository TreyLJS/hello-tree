

//鼠标滑过菜单显示
showMenu();
function showMenu(){
	var menuLi = $('.wrap-main .container-main .main .main-inner .inner-l ul.inner-l-menu li');
	var menuMain = $('.wrap-main .container-main .main .main-inner .inner-l .inner-l-main .inner-l-main-container');
	for(var i=0;i<menuLi.length;i++){
		menuLi.on('mouseenter',function(){
			var j = $(this).index();
			menuMain.eq(j).addClass('on');
			menuMain.eq(j).siblings().removeClass('on');
			menuMain.eq(j).addClass('on');
		$(this).parent().parent().on('mouseleave',function(){
			menuMain.eq(j).removeClass('on')
		})
		})
	}
}


//m-up动画
mUpMove();
function mUpMove(){
	var upC = 0;
	var upContainer = $('.wrap-main .main .main-inner .inner-m .inner-m-up .m-up-container');
	var upPic = $('.wrap-main .main .main-inner .inner-m .inner-m-up .m-up-container .pic');
	var upDian = $('.wrap-main .main .main-inner .inner-m .inner-m-up .m-up-container .dian li');
	var upNext = $('.wrap-main .main .main-inner .inner-m .inner-m-up .m-up-container .next');
	var upPrev = $('.wrap-main .main .main-inner .inner-m .inner-m-up .m-up-container .prev');

	//自动滚动动画;
	function upAnimate(){
		upPic.animate({
			left :-upC * 520 + 'px'
		},300)
	}
	//自动滚动函数
	function upMove(){
		upC++;
		if(upC==6){
			upPic.css({left:'0px'});
			upC=1;
		}
		upAnimate();

		//圆点变色
		for(var i=0;i<upDian.length;i++){
			upDian.eq(i).css({background:"#fff"});
		}
		upC==5?upDian.eq(0).css({background:'#ff5000'}):upDian.eq(upC).css({background:'#ff5000'})
	}

	//初始自动滚动,圆点自动变色;
	var timer1 = setInterval(upMove,4000)

	//鼠标进入停止自动滚动,左右按钮出现；
	upContainer.on('mouseenter',function(){
		clearInterval(timer1);
		upNext.css({display:'block'});
		upPrev.css({display:'block'})
	})
	console.log()
	//鼠标点击圆点切换图片；
	for(var i=0;i<upDian.length;i++){
		upDian.eq(i).on('click',function(){
			upC=$(this).index();
			//圆点变色
			for(var i=0;i<upDian.length;i++){
				upDian.eq(i).css({background:"#fff"});
			}
			upC==5?upDian.eq(0).css({background:'#ff5000'}):upDian.eq(upC).css({background:'#ff5000'})

			//图片滚动
			upAnimate()
	})
	}

	//鼠标点击右按钮切换上一张；
	upNext.on('click',function(){
		upC++;
		if(upC==6){
			upC=1;
			upPic.css({left:'0px'})
		}
		//圆点变色
		for(var i=0;i<upDian.length;i++){
			upDian.eq(i).css({background:"#fff"});
		}
		upC==5?upDian.eq(0).css({background:'#ff5000'}):upDian.eq(upC).css({background:'#ff5000'})

		//图片滚动
		upAnimate()
	})

	//鼠标点击做按钮返回上一张；
	upPrev.on('click',function(){
		upC--;
		if(upC==-1){
			upC=4;
			upPic.css({left:'-2600px'})
		}
		//圆点变色
		for(var i=0;i<upDian.length;i++){
			upDian.eq(i).css({background:"#fff"});
		}
		upC==5?upDian.eq(0).css({background:'#ff5000'}):upDian.eq(upC).css({background:'#ff5000'})

		//图片滚动
		upAnimate()
	})

	//鼠标移开继续自动滚动；
	upContainer.on('mouseleave',function(){
		timer1 = setInterval(upMove,4000);
		upNext.css({display:'none'});
		upPrev.css({display:'none'})
	})
}


//m-down动画
mDownMove()
function mDownMove(){
	var downC = 0;
	var downContainer = $('.wrap-main .main .main-inner .inner-m .inner-m-down .m-down-container');
	var downPic = $('.wrap-main .main .main-inner .inner-m .inner-m-down .m-down-container .pic');
	var downDian = $('.wrap-main .main .main-inner .inner-m .inner-m-down .m-down-container .dian li');
	var downNext = $('.wrap-main .main .main-inner .inner-m .inner-m-down .m-down-container .next');
	var downPrev = $('.wrap-main .main .main-inner .inner-m .inner-m-down .m-down-container .prev');
	var downText = $('.wrap-main .main .main-inner .inner-m .inner-m-down .m-down-container h5 em span');

	//自动滚动动画;
	function downAnimate(){
		downPic.animate({
			left :-downC * 520 + 'px'
		},300)
	}
	//自动滚动函数
	function downMove(){
		downC++;
		if(downC==7){
			downPic.css({left:'0px'});
			downC=1;
		}
		downAnimate();

		//圆点变色
		for(var i=0;i<downDian.length;i++){
			downDian.eq(i).css({background:"#ff5000"});
		}
		downC==6?downDian.eq(0).css({background:'black'}):downDian.eq(downC).css({background:'black'})
		downC==6?downText.text('1'):downText.text(downC + 1);
	}

	//初始自动滚动,圆点自动变色;
	var timer2 = setInterval(downMove,4000)

	//鼠标进入停止自动滚动,左右按钮出现；
	downContainer.on('mouseenter',function(){
		clearInterval(timer2);
		downNext.css({display:'block'});
		downPrev.css({display:'block'})
	})
	console.log()
	//鼠标点击圆点切换图片；
	for(var i=0;i<downDian.length;i++){
		downDian.eq(i).on('click',function(){
			downC=$(this).index();
			//圆点变色
			for(var i=0;i<downDian.length;i++){
				downDian.eq(i).css({background:"#ff5000"});
			}
			downC==6?downDian.eq(0).css({background:'black'}):downDian.eq(downC).css({background:'black'})
			downC==6?downText.text('1'):downText.text(downC + 1);

			//图片滚动
			downAnimate()
	})
	}

	//鼠标点击右按钮切换上一张；
	downNext.on('click',function(){
		downC++;
		if(downC==7){
			downC=1;
			downPic.css({left:'0px'})
		}
		//圆点变色
		for(var i=0;i<downDian.length;i++){
			downDian.eq(i).css({background:"#ff5000"});
		}
		downC==6?downDian.eq(0).css({background:'black'}):downDian.eq(downC).css({background:'black'});
		downC==6?downText.text('1'):downText.text(downC + 1);

		//图片滚动
		downAnimate()
	})

	//鼠标点击做按钮返回上一张；
	downPrev.on('click',function(){
		downC--;
		if(downC==-1){
			downC=5;
			downPic.css({left:'-3120px'})
		}
		//圆点变色
		for(var i=0;i<downDian.length;i++){
			downDian.eq(i).css({background:"#ff5000"});
		}
		downC==6?downDian.eq(0).css({background:'black'}):downDian.eq(downC).css({background:'black'});
		downC==6?downText.text('1'):downText.text(downC + 1);

		//图片滚动
		downAnimate()
	})

	//鼠标移开继续自动滚动；
	downContainer.on('mouseleave',function(){
		timer2 = setInterval(downMove,4000);
		downNext.css({display:'none'});
		downPrev.css({display:'none'})
	})
}


//淘宝news动画
tbNewsMove();
function tbNewsMove(){
	var tbNewsUl = $('.wrap-main .main .main-outer .taobao-news ul');
	var tbNewsC = 0;


	function tNMove(){
		tbNewsC++;
		if(tbNewsC==3){
			tbNewsC=0;
		}
		tbNewsUl.animate({
			top : -tbNewsC*73 + 'px'
		},300)
	}
	var timer3 = setInterval(tNMove,4500);

	tbNewsUl.on('mouseenter',function(){
		clearInterval(timer3);
	})
	tbNewsUl.on('mouseleave',function(){
		timer3 = setInterval(tNMove,4500)
	})
}


//淘宝公告滑过显示
announcementShow();
function announcementShow(){
	var announcementList = $('.wrap-main .col-right .col-right-announcement .announcement-list li');
	var announcementContent = $('.wrap-main .col-right .col-right-announcement .announcement-content li');
	var aC;
	for(var i=0;i<announcementList.length;i++){
		announcementList.eq(i).on('mouseenter',function(){
			aC = $(this).index();
			$(this).css({
				color:'#ff5000',
				fontWeight:'bold',
				borderBottom:'2px solid #ff5000'
			})
			$(this).siblings().css({
				color:'#3c3c3c',
				fontWeight:'normal',
				borderBottom:'none'
			})
			announcementContent.eq(aC).css({display:'block'});
			announcementContent.eq(aC).siblings().css({display:'none'});
		})
	}
	
}
