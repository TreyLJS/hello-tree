
waterFall();
$(window).resize(function(){
	waterFall();
})

//瀑布流
function waterFall () {
    //拿到所有的盒子
    var allBox = $('.wrap-main .box');
    //取出其中一个盒子的宽度
    var boxWidth = $(allBox).eq(0).outerWidth();
    //取出屏幕的高度
    var screenWidth = $('.wrap-main').width();
    //求出列数 //取整函数取整
    var cols = Math.floor( $('.wrap-main').width()/boxWidth) +1;
   
    //对子盒子定位
    var heightArr = [];
    //遍历
    $(allBox).each(function (index,value) {
        //取出单独盒子的高度
        var boxHeight = $(value).outerHeight();
        //判断是否第一行
        if(index < cols)
        {
            heightArr[index] = boxHeight;
        }
        else  //剩余的盒子要瀑布流布局
        {
            //求出最矮的盒子高度
            var minBoxHeight = Math.min.apply(null,heightArr);
            //取出最矮高度对应的索引  封装了js的这个方法
            var minBoxIndex = $.inArray(minBoxHeight,heightArr);
            //定位
            $(value).css({
                'position':'absolute',
                'top':minBoxHeight  + 'px',
                'left':minBoxIndex * boxWidth + 'px'
            });
            //更新数组中最矮的高度
            heightArr[minBoxIndex] += boxHeight;
        }
    })
}

//点击弹出
var box = $('.wrap-main .row .box');
var len = box.length;
var c;

for(var i=0;i<len;i++){
    box.eq(i).click(function(){
        c = $(this).index();
        var oSrc = box.eq(c).children('.img').attr('src');
        var oText = box.eq(c).children('.content').html();
        $('.t-cover').css({display:'block'});
        $('.t-cover .t-pic').attr('src',oSrc)
      
        var oWidth = $('.t-cover .t-pic').width();
        var oLeft = $('.t-cover .t-pic').position().left;

        $('.t-cover .t-text').html(oText).css({
            width:oWidth + 'px',
        });
        $('.t-cover .t-box').css({
            width:oWidth + 'px'
        })
        console.log($(window).scrollTop())
        return c;
    })
}
//点击下一张
$('.t-cover .t-next').click(function(){
    c++;
    if(c==24){ c=0; }

    var oSrc = box.eq(c).children('.img').attr('src');
    var oText = box.eq(c).children('.content').html();

    $('.t-cover').css({display:'block'});
    $('.t-cover .t-pic').attr('src',oSrc)
  
    var oWidth = $('.t-cover .t-pic').width();
    var oLeft = $('.t-cover .t-pic').position().left;
    console.log(oLeft);
    console.log(oWidth)

    $('.t-cover .t-text').html(oText).css({
        width:oWidth + 'px',
    });
})

//点击上一张
$('.t-cover .t-prev').click(function(){
    c--;
    if(c == -1){ c=23; }

    var oSrc = box.eq(c).children('.img').attr('src');
    var oText = box.eq(c).children('.content').html();

    $('.t-cover').css({display:'block'});
    $('.t-cover .t-pic').attr('src',oSrc)
  
    var oWidth = $('.t-cover .t-pic').width();
    var oLeft = $('.t-cover .t-pic').position().left;
    console.log(oLeft);
    console.log(oWidth)

    $('.t-cover .t-text').html(oText).css({
        width:oWidth + 'px',
    });
})


//点击关闭
$('.t-cover .t-close').click(function(){
    $('.t-cover').css({display:'none'})
})

// 滚动出现top
$(window).scroll(function(){
    if(parseInt($(window).scrollTop()) > 200){
        $('.toTop').css({
            display:'block',
            position:'fixed',
            right:'40px',
            bottom:'60px',
        })
    }else{
        $('.toTop').css({display:'none'})
    }
})
// $('.toTop').click(function(){
//     $('body').animate({
//         scrollTop:'0'
//     }, 300); 
// })

// 设置滚动动画
$('.toTop').on('click',function(){    
    $('body,html').animate({scrollTop:'0'},500)
}); 
