var today = new Date();
$('.date').text((today.getMonth()+1) + '/' + today.getDate() )

function mainContent(mypage,main){
	//选择页面及slide
	var oLi = $('.' + mypage + ' .slide .' + main + ' li');

	//取随机数
	function random(min,max){
		return parseInt(Math.random()*(max-min)+min)
	}

	//初始样式
	var arrTop=[];
	var arrLeft=[];
	for(var i=0;i<oLi.length;i++){
		arrTop[i]=random(850,2100);
		arrLeft[i]=random(1,1000)
		oLi.eq(i).css({
			top:arrTop[i] + "px",
			left:arrLeft[i] + "px"
		})
	}




	//自动滚动函数
	function move(){
		for(var i=0;i<oLi.length;i++){
			arrTop[i]-=1;
			if(arrTop[i]<-500){
				arrTop[i]=random(850,2100);
				arrLeft[i]=random(1,1000)
			}
			oLi.eq(i).css({
				top:arrTop[i] + "px",
				left:arrLeft[i] + "px"
			})
		}
	}

	//开始初始滚动
	var timer1 = setInterval(move
	,10)

	var c,
		thisTop,
		timer2;

	for(var i=0;i<oLi.length;i++){
		//鼠标进入停止初始滚动，其他元素继续滚动
		oLi.eq(i).mouseenter(function(){
			//显示链接
			var thisDiv = $(this).children('div');
			var divWidth = thisDiv.width();
			thisDiv.css({
				display:'block',
				left:-divWidth + 'px'
			})


			//停止初始滚动
			clearInterval(timer1);
			c = $(this).index();
			thisTop = $(this).position().top;
		
			//其他元素继续滚动
			timer2 = setInterval(function(){
				for(var j=0;j<oLi.length;j++){
					if(j==c){
						arrTop[j]=thisTop;
					}else{
						arrTop[j]-=1;
						if(arrTop[j]<-500){
							arrTop[j]=random(850,2100);
							arrLeft[j]=random(1,1000)
						}
					}
					oLi.eq(j).css({
						top:arrTop[j] + "px",
						left:arrLeft[j] + "px"
					})
				}
			},10)


		})

		//鼠标移出回复全部滚动
		oLi.eq(i).mouseleave(function(){
			clearInterval(timer2)
			timer1=setInterval(move,10)

			//隐藏链接
			var thisDiv = $(this).children('div');
			var divWidth = thisDiv.width();
			thisDiv.css({
				display:'none',
				// left:-divWidth + 'px'

			})

		})
	}
}

$('.btn-2-1').click(function(){
	mainContent('mypage2','main1');
	$(this).css({
		display:'none'
	})
})
$('.btn-2-2').click(function(){
	mainContent('mypage2','main2');
	$(this).css({
		display:'none'
	})
})
$('.btn-3-1').click(function(){
	mainContent('mypage3','main1');
	$(this).css({
		display:'none'
	})
})
$('.btn-3-2').click(function(){
	mainContent('mypage3','main2');
	$(this).css({
		display:'none'
	})
})
$('.btn-4-1').click(function(){
	mainContent('mypage4','main1');
	$(this).css({
		display:'none'
	})
})
$('.btn-4-2').click(function(){
	mainContent('mypage4','main2');
	$(this).css({
		display:'none'
	})
})
$('.btn-5-1').click(function(){
	mainContent('mypage5','main1');
	$(this).css({
		display:'none'
	})
})
$('.btn-5-2').click(function(){
	mainContent('mypage5','main2');
	$(this).css({
		display:'none'
	})
})
$('.btn-5-3').click(function(){
	mainContent('mypage5','main3');
	$(this).css({
		display:'none'
	})
})
$('.btn-5-4').click(function(){
	mainContent('mypage5','main4');
	$(this).css({
		display:'none'
	})
})

