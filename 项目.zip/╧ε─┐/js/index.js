var code = document.getElementsByClassName('code')[0];
var img = code.getElementsByTagName('img')[0];
code.onmouseenter=function(){
	img.style.display = "block";
}
code.onmouseleave = function(){
	img.style.display = "none";
}
var c=1;

// var timer1 = setInterval(function(){
// 	c == 7?c=1:c++;
// 	$('body').animate({
// 		backgroundImage:"url(./img/bg" + c + ".png)"
// 	},200)
	
// },20000)
$('.nav li').mouseenter(function(){
	$(this).css(
		"background-color","#78D8F5"
	)
})
$('.nav li').mouseleave(function(){
	$(this).css("background-color","#8CB8F4")
});
$('.wrap .wrap-login .container-login .login ul li:eq(0)').click(goLogin);
$('.t-login .close-login').click(close);
$('.wrap .wrap-login .container-login .login ul li:eq(2)').click(goRegister);
$('.t-register .close-register').click(close);
$('.t-login .goReg').click(goRegister);
$('.t-register .goLogin').click(goLogin);

//关闭登录、注册界面
function close(){
	$('.t-login').css({display:"none",});
	$('.t-cover').css({display:"none"});
	$('.t-register').css({display:"none",});
	$('.t-register ul li input').val('');
	$('.t-login ul li input').val('');
}
//打开登录界面
function goLogin(){
	$('.t-login').css({display:"block",});
	$('.t-cover').css({display:"block"});
	$('.t-register').css({display:"none",});
}
//打开注册界面
function goRegister(){
	$('.t-login').css({display:"none",});
	$('.t-register').css({display:"block",});
	$('.t-cover').css({display:"block"})
}

//错误提醒
function regError(obj,text){
	$(obj).next('p').html(text)
	$(obj).next('p').css({
		display:"block",
		backgroundColor:'#fce4e4',
		fontSize: '14px',
		float: 'left',
		width: '170px',
		height: '36px',
		color: '#ff6767',
		marginLeft: '20px',
		lineHeight:'18px'
	})
	
}

//正确输入
function regRight(obj){
	$(obj).next('p').html('&#xe6b1;')
	$(obj).next('p').css({
		display:'block',
		backgroundColor:'#fff',
		color:'green',
		fontSize:'20px',
		width:'170px',
		height:'36px',
		lineHeight:'36px',
		float:'left',
		marginLeft:'20px'
	})
}

//邮箱地址
$('.t-register ul li:eq(2) input').focusout(function(){
	var str = $(this).val();
	var reg =/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/g;
	var obj=$(this);
	str ===""?$(obj).next('p').html('').css({backgroundColor:'#fff'})
	:reg.test(str)?regRight(obj):regError(obj,'请输入正确的邮箱地址，如：abc@123.com')
	// if(!reg.test(str)){
	// 	regError(obj,'请输入正确的邮箱地址，如：abc@123.com')
	// }else{
	// 	regRight(obj)	
	// }
})

//密码
var password;
$('.t-register ul li:eq(3) input').focusout(function(){
	password = $(this).val();
	var reg =/^[\w`~!@#$%^&*()-_=+.,/?]{6,16}$/g ;
	var obj = $(this);
	password===""?$(obj).next('p').html('').css({backgroundColor:'#fff'})
	:reg.test(password)?regRight(obj):regError(obj,'密码长度应该在6-16个字符之间')
})

//确认密码
$('.t-register ul li:eq(4) input').focusout(function(){
	var str = $(this).val();
	var obj = $(this);
	str===""?$(obj).next('p').html('').css({backgroundColor:'#fff'})
	:str === password?regRight(obj):regError(obj,'您两次输入的密码不一致')
})

//手机号码
$('.t-register ul li:eq(5) input').focusout(function(){
	var str = $(this).val();
	var reg = /^1\d{10}$/g;
	var obj = $(this);
	str===""?obj.next('p').html('').css({backgroundColor:'#fff'})
	:reg.test(str)?regRight(obj):regError(obj,'手机号码格式输入错误');
})

//验证码
//1.生成随机数
function random(min,max){
	return parseInt(Math.random()*(max-min)+min)
}
//2.初始验证码
var num1 = random(0,9);
var num2 = random(0,9);
var num3 = random(0,9);
var num4 = random(0,9);
var num5 = random(0,9);
var num = num1.toString() + num2 + num3 +num4 +num5;
console.log(num);
$('.t-register ul li.robot strong').text(num);

//3.点击切换验证码
$('.t-register ul li.robot strong').click(function(){
	num1 = random(0,9);
	num2 = random(0,9);
	num3 = random(0,9);
	num4 = random(0,9);
	num5 = random(0,9);
	num = num1.toString() + num2 + num3 +num4 +num5;
	$(this).text(num);
	console.log(num);
})
//4.判断验证码输入是否正确
$('.t-register ul .robot input').focusout(function(){
	var str = $(this).val();
	var obj = $('.t-register ul li.robot strong');
	if(str===""){
		obj.next('p').html('').css({backgroundColor:'#fff'})
	}else if(str == num){
		$(obj).next('p').html('&#xe6b1;')
		$(obj).next('p').css({
			display:'block',
			backgroundColor:'#fff',
			color:'green',
			fontSize:'20px',
			width:'100px',
			height:'36px',
			lineHeight:'36px',
			float:'left',
			marginLeft:'20px'
		})
	}else{
		$(obj).next('p').html('输入错误')
		$(obj).next('p').css({
			display:"block",
			backgroundColor:'#fce4e4',
			fontSize: '14px',
			float: 'left',
			width: '100px',
			height: '36px',
			color: '#ff6767',
			marginLeft: '20px',
			lineHeight:'18px'
		})
	}
})